const fetch = require('node-fetch')

const handler = async function (event, context, callback) {
  // fb webhook verification
  // See https://developers.facebook.com/docs/graph-api/webhooks/getting-started
  // Endpoint: https://connect.treeoflight.earth/.netlify/functions/events-background
  const {mode, challenge, verify_token } = hub;
  const token = verify_token === (process.env.FACEBOOK_EVENTS_WEBHOOK_TOKEN || "hgiuygi6tu6ti7uyfgiukygkuygo78");
  const errorMessage = "Your token did not match";
  if (token) {
    return {
      statusCode: 200,
      // Could be a custom message or object i.e. JSON.stringify(err)
      body: JSON.stringify({ mode, challenge }),
    }
  }
  return {
    statusCode: 500,
    // Could be a custom message or object i.e. JSON.stringify(err)
    body: JSON.stringify({ mode, challenge, error: errorMessage }),
  }
  /* 
  try {
    const response = await fetch('https://icanhazdadjoke.com', {
      headers: { Accept: 'application/json' },
    })
    if (!response.ok) {
      // NOT res.status >= 200 && res.status < 300
      return { statusCode: response.status, body: response.statusText }
    }
    const data = await response.json()

    return {
      statusCode: 200,
      body: JSON.stringify({ msg: data.joke }),
    }
  } catch (error) {
    // output to netlify function log
    console.log(error)
    return {
      statusCode: 500,
      // Could be a custom message or object i.e. JSON.stringify(err)
      body: JSON.stringify({ msg: error.message }),
    }
  }
  */
}

module.exports = { handler }
